=== Plugin Name ===
Contributors: leonstafford
Donate link: https://leonstafford.github.io
Tags: wp2static,github,static
Requires at least: 3.2
Tested up to: 5.0.3
Stable tag: 0.1
License: Unlicense
License URI: http://unlicense.org

Adds AWS GitHub as a deployment option for WP2Static.

== Description ==

Take advantage of the GitHub and optionally CloudFront to host your WordPress
 powered static website.

== Installation ==

Upload the ZIP to your WordPress plugins page within your dashboard.

Activate the plugin, then navigate to your WP2Static main plugin page to see
 the new deployment option available.

== Changelog ==

= 0.1 =

First release
